export type IconProps = {
    size?: number;
    className?: string;
}